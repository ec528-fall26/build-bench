DEMO 2 HANDOFF v4 — completed paired evaluation review, 19 October 2026

Start with docs/demo2-comparison-diagnostics.md, then docs/design-document.md.
All 22 summary rows were checked against original records. One-shot: 0/11.
Full agent: 1/11 (rcran). Each arm: five reverse-direction setup failures,
four unrepaired native development cases, one unchanged success, plus rcran.
Original plans, records, patches and summaries are included; selected logs
are excerpted with line numbers and source hashes in paired-retest/audit.json.

INSTALL ON MAC, from the extracted handoff folder:
python3 install.py --repo "$HOME/Desktop/BuildBench/build-bench"

Then from your repository:
python3 -m unittest discover -s tests/demo2 -p 'test_*.py'
python3 scripts/demo2_evidence_report.py
git diff --check
git status --short

The installer backs up differing existing files to Downloads before replacing
them. Review and commit the installed documents, evidence, scripts and tests.
No agent source changes or automatic experiments. The two TA drivers are
included from the preceding handoff; their 13 offline tests pass. Their final
clean-machine real-build acceptance check remains outstanding.

Do not rerun the expensive 22-job schedule merely to document these results.
Review the setup failures first. Optional proposed-diff review was OFF in the
completed full-agent run. Its raised budgets are recorded in the original plan;
the TA driver does not silently reproduce those local source changes.
