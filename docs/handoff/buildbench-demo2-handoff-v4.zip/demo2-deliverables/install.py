#!/usr/bin/env python3
"""Install the Demo 2 documents, drivers and evidence; back up any changed destination."""
import argparse
from datetime import datetime
from pathlib import Path
import shutil

FILES = (
    'docs/design-document.md',
    'docs/demo2-comparison-diagnostics.md',
    'docs/evidence/demo2/paired-retest/audit.json',
    'docs/evidence/demo2/paired-retest/full-agent/01-launchpad-mantic-amd64-arm64-r-cran-digest-7a42effc961f/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/01-launchpad-mantic-amd64-arm64-r-cran-digest-7a42effc961f/repair.diff',
    'docs/evidence/demo2/paired-retest/full-agent/02-launchpad-jammy-arm64-amd64-libbpp-core-13069fd09280/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/03-launchpad-noble-amd64-arm64-ectrans-50e45e72102d/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/03-launchpad-noble-amd64-arm64-ectrans-50e45e72102d/repair.diff',
    'docs/evidence/demo2/paired-retest/full-agent/04-launchpad-noble-amd64-arm64-libmceliece-5020df9683fc/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/04-launchpad-noble-amd64-arm64-libmceliece-5020df9683fc/repair.diff',
    'docs/evidence/demo2/paired-retest/full-agent/05-launchpad-noble-arm64-amd64-libbpp-qt-32eb71858f9f/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/06-launchpad-noble-arm64-amd64-python-intbitset-0ede6db7f446/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/06-launchpad-noble-arm64-amd64-python-intbitset-0ede6db7f446/repair.diff',
    'docs/evidence/demo2/paired-retest/full-agent/07-launchpad-plucky-amd64-arm64-libunwind-f18b55e03a91/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/07-launchpad-plucky-amd64-arm64-libunwind-f18b55e03a91/repair.diff',
    'docs/evidence/demo2/paired-retest/full-agent/08-launchpad-plucky-amd64-arm64-rust-subversion-b3a4b8c35bb2/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/09-launchpad-plucky-arm64-amd64-libevtx-1ee53325da7e/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/10-launchpad-resolute-amd64-arm64-html-xml-utils-fe68b3f14b84/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/11-launchpad-resolute-arm64-amd64-pybigwig-56ac842288ce/record.json',
    'docs/evidence/demo2/paired-retest/full-agent/local-settings.diff',
    'docs/evidence/demo2/paired-retest/full-agent/plan.json',
    'docs/evidence/demo2/paired-retest/full-agent/summary.json',
    'docs/evidence/demo2/paired-retest/one-shot/01-launchpad-mantic-amd64-arm64-r-cran-digest-7a42effc961f/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/01-launchpad-mantic-amd64-arm64-r-cran-digest-7a42effc961f/repair.diff',
    'docs/evidence/demo2/paired-retest/one-shot/02-launchpad-jammy-arm64-amd64-libbpp-core-13069fd09280/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/03-launchpad-noble-amd64-arm64-ectrans-50e45e72102d/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/03-launchpad-noble-amd64-arm64-ectrans-50e45e72102d/repair.diff',
    'docs/evidence/demo2/paired-retest/one-shot/04-launchpad-noble-amd64-arm64-libmceliece-5020df9683fc/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/04-launchpad-noble-amd64-arm64-libmceliece-5020df9683fc/repair.diff',
    'docs/evidence/demo2/paired-retest/one-shot/05-launchpad-noble-arm64-amd64-libbpp-qt-32eb71858f9f/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/05-launchpad-noble-arm64-amd64-libbpp-qt-32eb71858f9f/repair.diff',
    'docs/evidence/demo2/paired-retest/one-shot/06-launchpad-noble-arm64-amd64-python-intbitset-0ede6db7f446/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/07-launchpad-plucky-amd64-arm64-libunwind-f18b55e03a91/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/08-launchpad-plucky-amd64-arm64-rust-subversion-b3a4b8c35bb2/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/09-launchpad-plucky-arm64-amd64-libevtx-1ee53325da7e/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/09-launchpad-plucky-arm64-amd64-libevtx-1ee53325da7e/repair.diff',
    'docs/evidence/demo2/paired-retest/one-shot/10-launchpad-resolute-amd64-arm64-html-xml-utils-fe68b3f14b84/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/11-launchpad-resolute-arm64-amd64-pybigwig-56ac842288ce/record.json',
    'docs/evidence/demo2/paired-retest/one-shot/11-launchpad-resolute-arm64-amd64-pybigwig-56ac842288ce/repair.diff',
    'docs/evidence/demo2/paired-retest/one-shot/plan.json',
    'docs/evidence/demo2/paired-retest/one-shot/summary.json',

    'docs/demo2-one-shot-results.md',
    'docs/evidence/demo2/one-shot-retest-summary.json',
    'docs/evidence/demo2/comparison-records.json',
    'docs/evidence/demo2/development-cases.json',
    'scripts/demo2_demo.py',
    'scripts/demo2_retest.py',
    'scripts/demo2_evidence_report.py',
    'tests/demo2/test_demo2_demo.py',
    'tests/demo2/test_demo2_retest.py',
)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    args = p.parse_args()
    root = args.repo.expanduser().resolve()
    source = Path(__file__).resolve().parent
    if not (root / 'harness/run_case.py').is_file():
        p.error('Expected the complete build-bench repository, containing harness/run_case.py.')
    changes = []
    for name in FILES:
        target = root / name
        for part in (target, *target.parents):
            if part == root:
                break
            if part.is_symlink():
                p.error('Refusing symlink destination: ' + str(part))
        if target.exists() and not target.is_file():
            p.error('Destination is not a regular file: ' + str(target))
        if target.exists() and target.read_bytes() == (source / name).read_bytes():
            continue
        changes.append((name, target))
    backup = Path.home() / 'Downloads' / ('buildbench-doc-backup-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    for name, target in changes:
        if target.exists():
            saved = backup / name
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / name, target)
        print('Installed:', target)
    if backup.exists():
        print('Previous files backed up:', backup)
    print('No agent source changed. No model calls or builds started. Review and commit these files before EC2 use.')

if __name__ == '__main__':
    main()
